package af.spring;

import org.springframework.web.servlet.View;

/** 自定义 REST View, 下辖子类 RestData, RestError

 */
public interface AfRestView extends View
{

}
