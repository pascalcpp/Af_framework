package my.controls;

import java.awt.Color;

import javax.swing.JButton;

import af.swing.AfButton;

public class DefaultButton extends AfButton
{
	public DefaultButton(String title)
	{
		super(title);
		
		normal.borderColor = new Color(0x708090);
		normal.textColor = new Color(0xFCFCFC);
		normal.bgColor = new Color(0xC04A708B, true);
		hover.bgColor = new Color(0xA09AC0CD, true);
	}
}
