package my.controls;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import af.swing.AfButton;

public class CommonButton extends AfButton
{
	public CommonButton(String title)
	{
		super(title);		
	}
}
