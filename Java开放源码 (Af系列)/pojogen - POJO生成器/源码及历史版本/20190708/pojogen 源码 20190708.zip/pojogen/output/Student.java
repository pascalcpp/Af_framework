package my.db; 

import af.sql.annotation.AFCOLUMNS; 
import af.sql.annotation.AFTABLE; 
import java.util.Date; 

// 本类由 【POJO生成器】 自动生成 ：2019-07-08 10:35:55

@AFTABLE(name="student")  
@AFCOLUMNS() 
public class Student 
{ 
 
	public Integer id ; 
	public String name ; 
	public Boolean sex ; 
	public String phone ; 
	public Date birthday ; 


	public void setId(Integer id)
	{
		this.id=id;
	}
	public Integer getId()
	{
		return this.id;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return this.name;
	}
	public void setSex(Boolean sex)
	{
		this.sex=sex;
	}
	public Boolean getSex()
	{
		return this.sex;
	}
	public void setPhone(String phone)
	{
		this.phone=phone;
	}
	public String getPhone()
	{
		return this.phone;
	}
	public void setBirthday(Date birthday)
	{
		this.birthday=birthday;
	}
	public Date getBirthday()
	{
		return this.birthday;
	}

} 
 