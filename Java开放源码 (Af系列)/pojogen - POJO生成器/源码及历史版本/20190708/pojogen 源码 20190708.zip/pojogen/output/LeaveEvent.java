package my.db; 

import af.sql.annotation.AFCOLUMNS; 
import af.sql.annotation.AFTABLE; 
import java.util.Date; 

// 本类由 【POJO生成器】 自动生成 ：2019-07-08 10:35:55

@AFTABLE(name="leave_event")  
@AFCOLUMNS(generated="id") 
public class LeaveEvent 
{ 
 
	public Long id ; 
	public Integer stuId ; 
	public Date daysFrom ; 
	public Date daysTo ; 
	public Byte type ; 
	public String reason ; 


	public void setId(Long id)
	{
		this.id=id;
	}
	public Long getId()
	{
		return this.id;
	}
	public void setStuId(Integer stuId)
	{
		this.stuId=stuId;
	}
	public Integer getStuId()
	{
		return this.stuId;
	}
	public void setDaysFrom(Date daysFrom)
	{
		this.daysFrom=daysFrom;
	}
	public Date getDaysFrom()
	{
		return this.daysFrom;
	}
	public void setDaysTo(Date daysTo)
	{
		this.daysTo=daysTo;
	}
	public Date getDaysTo()
	{
		return this.daysTo;
	}
	public void setType(Byte type)
	{
		this.type=type;
	}
	public Byte getType()
	{
		return this.type;
	}
	public void setReason(String reason)
	{
		this.reason=reason;
	}
	public String getReason()
	{
		return this.reason;
	}

} 
 