package my.db; 

import af.sql.annotation.AFCOLUMNS; 
import af.sql.annotation.AFTABLE; 
import java.util.Date; 

// 本类由 【POJO生成器】 自动生成 ：2019-07-08 10:35:55

@AFTABLE(name="admin")  
@AFCOLUMNS() 
public class Admin 
{ 
 
	public String username ; 
	public String password ; 


	public void setUsername(String username)
	{
		this.username=username;
	}
	public String getUsername()
	{
		return this.username;
	}
	public void setPassword(String password)
	{
		this.password=password;
	}
	public String getPassword()
	{
		return this.password;
	}

} 
 