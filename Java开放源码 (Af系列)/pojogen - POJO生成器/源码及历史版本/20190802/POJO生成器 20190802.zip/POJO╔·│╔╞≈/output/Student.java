package my.db; 

import java.util.Date; 

// 本类由 POJO生成器 自动生成于 2019-08-02 15:29:23

public class Student 
{ 
 
	public Integer id ; 
	public String name ; 
	public Boolean sex ; 
	public String cellphone ; 


	public void setId(Integer id)
	{
		this.id=id;
	}
	public Integer getId()
	{
		return this.id;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return this.name;
	}
	public void setSex(Boolean sex)
	{
		this.sex=sex;
	}
	public Boolean getSex()
	{
		return this.sex;
	}
	public void setCellphone(String cellphone)
	{
		this.cellphone=cellphone;
	}
	public String getCellphone()
	{
		return this.cellphone;
	}

} 
 