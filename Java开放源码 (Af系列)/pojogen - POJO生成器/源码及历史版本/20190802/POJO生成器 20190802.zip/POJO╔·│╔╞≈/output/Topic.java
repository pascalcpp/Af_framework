package my.db; 

import java.util.Date; 

// 本类由 POJO生成器 自动生成于 2019-08-02 15:29:24

public class Topic 
{ 
 
	public Long id ; 
	public String title ; 
	public String content ; 
	public Integer numView ; 
	public Date timeCreated ; 


	public void setId(Long id)
	{
		this.id=id;
	}
	public Long getId()
	{
		return this.id;
	}
	public void setTitle(String title)
	{
		this.title=title;
	}
	public String getTitle()
	{
		return this.title;
	}
	public void setContent(String content)
	{
		this.content=content;
	}
	public String getContent()
	{
		return this.content;
	}
	public void setNumView(Integer numView)
	{
		this.numView=numView;
	}
	public Integer getNumView()
	{
		return this.numView;
	}
	public void setTimeCreated(Date timeCreated)
	{
		this.timeCreated=timeCreated;
	}
	public Date getTimeCreated()
	{
		return this.timeCreated;
	}

} 
 