package my.db; 

import java.util.Date; 

// 本类由 POJO生成器 自动生成于 2019-08-02 15:29:23

public class Teacher 
{ 
 
	public Integer id ; 
	public String 姓名 ; 
	public String 科目 ; 


	public void setId(Integer id)
	{
		this.id=id;
	}
	public Integer getId()
	{
		return this.id;
	}
	public void set姓名(String 姓名)
	{
		this.姓名=姓名;
	}
	public String get姓名()
	{
		return this.姓名;
	}
	public void set科目(String 科目)
	{
		this.科目=科目;
	}
	public String get科目()
	{
		return this.科目;
	}

} 
 