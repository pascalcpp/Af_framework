package my.qianwen.db; 

import af.sql.annotation.AFCOLUMNS; 
import af.sql.annotation.AFTABLE; 
import java.util.Date; 

// 本类由 【POJO生成器】 自动生成 ：2019-06-03 21:57:05

@AFTABLE(name="question")  
@AFCOLUMNS(auto=true,generated="id") 
public class Question 
{ 
 
	public Long id ; 
	public String descr ; 
	public String digest ; 
	public String answer ; 
	public Boolean isFree ; 
	public Boolean isNice ; 
	public Integer numView ; 
	public Integer numLike ; 
	public Integer numAnswer ; 
	public Date timeCreated ; 
	public Date timeModified ; 


	public void setId(Long id)
	{
		this.id=id;
	}
	public Long getId()
	{
		return this.id;
	}
	public void setDescr(String descr)
	{
		this.descr=descr;
	}
	public String getDescr()
	{
		return this.descr;
	}
	public void setDigest(String digest)
	{
		this.digest=digest;
	}
	public String getDigest()
	{
		return this.digest;
	}
	public void setAnswer(String answer)
	{
		this.answer=answer;
	}
	public String getAnswer()
	{
		return this.answer;
	}
	public void setIsFree(Boolean isFree)
	{
		this.isFree=isFree;
	}
	public Boolean getIsFree()
	{
		return this.isFree;
	}
	public void setIsNice(Boolean isNice)
	{
		this.isNice=isNice;
	}
	public Boolean getIsNice()
	{
		return this.isNice;
	}
	public void setNumView(Integer numView)
	{
		this.numView=numView;
	}
	public Integer getNumView()
	{
		return this.numView;
	}
	public void setNumLike(Integer numLike)
	{
		this.numLike=numLike;
	}
	public Integer getNumLike()
	{
		return this.numLike;
	}
	public void setNumAnswer(Integer numAnswer)
	{
		this.numAnswer=numAnswer;
	}
	public Integer getNumAnswer()
	{
		return this.numAnswer;
	}
	public void setTimeCreated(Date timeCreated)
	{
		this.timeCreated=timeCreated;
	}
	public Date getTimeCreated()
	{
		return this.timeCreated;
	}
	public void setTimeModified(Date timeModified)
	{
		this.timeModified=timeModified;
	}
	public Date getTimeModified()
	{
		return this.timeModified;
	}

} 
 