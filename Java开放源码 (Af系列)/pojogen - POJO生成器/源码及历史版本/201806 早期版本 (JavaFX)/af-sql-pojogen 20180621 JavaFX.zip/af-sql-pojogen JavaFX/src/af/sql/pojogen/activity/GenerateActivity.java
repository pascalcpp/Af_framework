package af.sql.pojogen.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;

import af.javafx.activity.AfActivity;
import af.javafx.layout.AfLayoutPane;
import af.javafx.progressbar.AfWaitingBar;
import af.sql.AfSql;
import af.sql.AfSqlConnection;
import af.sql.AfSqlReflect;
import af.sql.AfSqlWhere;
import af.sql.mapping.AfSqlPojo;
import af.sql.pojogen.DBInfo;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

/* 生成 POJO类
 * 
 */

public class GenerateActivity extends AfActivity
{
	// 输入参数
	DBInfo info;
	
	// ui
	LayoutPane ui;
	
	public GenerateActivity()
	{		
	}
	
	@Override
	public void onCreate(Object intent)
	{
		// 取得参数
		info = (DBInfo) intent;
		
		// 布局
		ui = new LayoutPane();
		this.setContentView(ui);
		ui.getStyleClass().add("activity");		
	}

	@Override
	public void onStart()
	{
		ui.wbar.startAnimation();
		new GenTask().start();
	}

	@Override
	public void onStop()
	{
		
	}
	
	//////////////////////////////
	private class LayoutPane extends AfLayoutPane
	{
		AfWaitingBar wbar = new AfWaitingBar();
		public LayoutPane()
		{
			this.getChildren().addAll(wbar);
			wbar.setBgColor(Color.web("#f1f1f1"));
		}
		@Override
		protected void layoutChilderen(double w, double h)
		{
			wbar.resizeRelocate(20, h/2-20, w-40, 30);
		}
		
	}
	//////////////////////////////
	private class GenTask extends Thread
	{
		List<String> tables = info.tables;
		
		@Override
		public void run()
		{						
			//
			File generated = new File("./generated");
			
			// 先清除原有文件
			try {
				//if(generated.exists()) generated.delete();
				FileUtils.deleteQuietly(generated);
			}catch(Exception e) {}
			
			generated.mkdirs();
			
			for(String table: tables)
			{
				try {
					AfSqlPojo pojo = tableInfo ( table);
					
					pojo.name = AfSql.className4Table(table);
					File file = new File(generated, pojo.name + ".java");
					generateJavaClass(pojo,  file);
					showProgress(true, "生成: " + file.getAbsolutePath());
				}catch(Exception e)
				{
					e.printStackTrace();
				}
			}	
			
			// 任务已完成 ...
			Platform.runLater( ()->{
				ui.wbar.clear();
				startActivity( SummaryActivity.class, info);
			});			
		}
		
		public void showProgress(boolean ok, String text)
		{
			System.out.println(text);
		}
		
		private void listTables() throws Exception
		{
			AfSqlWhere where = new AfSqlWhere();
			where.add2("table_schema", info.catalog);
			
			String sql = "select table_name from tables" + where;
			ResultSet rs = info.conn.executeQuery(sql);
			while(rs.next())
			{
				String name = rs.getString(1);
				tables.add(name);
			}			
		}
		
		private AfSqlPojo tableInfo (String table) throws Exception
		{
			AfSqlPojo pojo = new AfSqlPojo();
			pojo.table = table;
			
			AfSqlWhere where = new AfSqlWhere();
			where.add2("table_schema", info.catalog);
			where.add2("table_name", table);
			
			String sql = "select column_name,data_type,column_type from columns" + where;
			ResultSet rs = info.conn.executeQuery(sql);
			while(rs.next())
			{
				AfSqlPojo.Property c = new AfSqlPojo.Property();
				c.name = rs.getString(1);
				c.type = rs.getString(2);
				c.arg1 = rs.getString(3);
				
				pojo.properties.add( c );
			}	
			
			return pojo;
		}
		

		
		private void generateJavaClass(AfSqlPojo pojo, File file) throws Exception
		{
			String text = "";
			
			text += String.format("package %s; \r\n\r\n",  info.packageName);
			
			text += "import af.sql.annotation.AFCOLUMNS; \r\n";
			text += "import af.sql.annotation.AFTABLE; \r\n";
			text += "import java.util.Date; \r\n";
			text += "\r\n";
			
			text += String.format("@AFTABLE(name=\"%s\")  \r\n", pojo.table);
			text += String.format("@AFCOLUMNS(auto=true) \r\n");
			
			text += String.format("public class %s \r\n", pojo.name);
			text += "{ \r\n ";
			
			String attributes = "";
			String functions = "";
			
			// 生成属性和方法
			for(AfSqlPojo.Property p : pojo.properties)
			{
				String attr = p.name;
				String type = "String";
				if(p.type.equals("tinyint")) 
				{
					type = "Byte";
					if(p.arg1.equals("tinyint(1)")) type= "Boolean";
				}
				
				if(p.type.equals("smallint")) type = "Short";
				if(p.type.equals("int")) type = "Integer";
				if(p.type.equals("bigint")) type = "Long";
				if(p.type.equals("datetime")) type = "Date";
				if(p.type.equals("bit")) type = "Boolean";
				if(p.type.equals("double")) type = "Double";
				if(p.type.equals("float")) type = "Float";
				
				// attributes
				if(true)
				{
					attributes += String.format("\tpublic %s %s ; \r\n", type, attr);
				}
					
				// setters and getters
				if(true)
				{					
					String func = AfSqlReflect.setter(attr );
					String fmt = "\tpublic void %s(%s %s)\r\n"
							+ "\t{\r\n"
							+ "\t\tthis.%s=%s;\r\n"
							+ "\t}\r\n";
					String str = String.format(fmt, func, type, attr, attr, attr);
					functions += str;
				}
				if(true)
				{					
					String func = AfSqlReflect.getter(attr );
					String fmt = "\tpublic %s %s()\r\n"
							+ "\t{\r\n"
							+ "\t\treturn this.%s;\r\n"
							+ "\t}\r\n";
					String str = String.format(fmt, type, func, attr);
					functions += str;
				}
			}
			// 生成方法
			text += "\r\n" + attributes + "\r\n";
			text += "\r\n" + functions + "\r\n";
			text += "} \r\n ";	
			
			FileOutputStream ostream = new FileOutputStream(file);
			ostream.write( text.getBytes("UTF-8") );
			ostream.close();
		}
		
		
		
	}
	

}
