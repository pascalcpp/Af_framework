package af.sql.pojogen;

import af.javafx.window.AfStyleWindowWrapper;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

public class PojoGen extends Application
{
	PojoGenWindow container = new PojoGenWindow();
	
	@Override
	public void start(Stage primaryStage)
	{
		try
		{
			
			
//			Scene scene = new Scene(container, 700, 400);
//			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
//			primaryStage.setScene(scene);
//			primaryStage.setTitle("pojo-gen for afsql");
//			primaryStage.show();
			MyToastr.install(primaryStage);
			
			AfStyleWindowWrapper ww = new AfStyleWindowWrapper(primaryStage, container);
			ww.resize(760, 560);
			ww.initDragSupport(null, false); // 固定窗口大小
			ww.show();
			ww.getScene().getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		
			container.getStyleClass().add("main");
			
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void main(String[] args)
	{
		launch(args);
	}
}
