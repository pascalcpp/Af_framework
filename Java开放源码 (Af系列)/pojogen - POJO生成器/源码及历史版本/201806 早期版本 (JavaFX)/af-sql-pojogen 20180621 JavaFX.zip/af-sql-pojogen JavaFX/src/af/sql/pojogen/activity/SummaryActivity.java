package af.sql.pojogen.activity;

import java.io.File;

import af.javafx.activity.AfActivity;
import af.javafx.process.AfProcess;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;


public class SummaryActivity extends AfActivity
{
	Button button = new Button("查看输出");
	
	public SummaryActivity()
	{
		
	}
	
	@Override
	public void onCreate(Object arg0)
	{
		StackPane root = new StackPane();
		this.setContentView(root);
		root.getStyleClass().add("activity");
		
		root.getChildren().add(button);
		StackPane.setAlignment( button, Pos.CENTER);
		
		button.getStyleClass().add("huge-button");
		
		button.setOnAction( (e)->{
			openBrowser();
		});
	}

	@Override
	public void onStart()
	{
		
	}

	@Override
	public void onStop()
	{
		
	}
	
	public void openBrowser()
	{
		try
		{			
			File f = new File("generated");
			String path = f.getCanonicalPath();
			String cmdline = String.format("explorer \"%s\" ", path);
			
			AfProcess.runDetached(cmdline);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
//	public static void main(String[] args)
//	{
//		try
//		{			
//			File f = new File("output");
//			String path = f.getCanonicalPath();
//			String cmdline = String.format("explorer \"%s\" ", path);
//			
//			AfProcess.runDetached(cmdline);
//		} catch (Exception e)
//		{
//			e.printStackTrace();
//		}
//	}

}
