package af.sql.pojogen.activity;

import java.io.File;
import java.util.HashMap;

import af.javafx.activity.AfActivity;
import af.javafx.task.AfAsyncTask;
import af.javafx.toastr.AfToastr;
import af.sql.AfMySQL;
import af.sql.AfSqlConnection;
import af.sql.pojogen.AfConfig;
import af.sql.pojogen.DBInfo;
import af.sql.pojogen.MyToastr;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class ConnectActivity extends AfActivity
{
	TextField username = new TextField();
	TextField password = new TextField();
	TextField server = new TextField();
	Button button = new Button("连接");
	
	public ConnectActivity()
	{
		
	}
	
	@Override
	public void onCreate(Object arg0)
	{
		StackPane root = new StackPane();
		this.setContentView(root);
		root.getStyleClass().add("activity");
		
		VBox vbox = new VBox();
		vbox.setMaxWidth(240);
		vbox.setMaxHeight( 300);
		vbox.setSpacing(10);
		vbox.getChildren().add(new Label("连接数据库"));
		vbox.getChildren().add(server);
		vbox.getChildren().add(username);
		vbox.getChildren().add(password);
		vbox.getChildren().add(button);
		vbox.setPadding(new Insets(10,0,0,0));
		
		server.setMaxWidth(9999);
		username.setMaxWidth(9999);
		password.setMaxWidth(9999);
		button.setMaxWidth(9999);
		
		root.getChildren().add( vbox );
		
		// 
		button.setOnAction( (e)->{
			saveConfig();
			doConnect();
		});
	}

	@Override
	public void onStart()
	{	
		
		loadConfig();		
		
	}

	@Override
	public void onStop()
	{		
	}
	
	
	public void loadConfig()
	{
		File f = new File("config.xml");
		AfConfig c = new AfConfig(f);

		// 加载xml
		try
		{
			c.load();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		String _server = c.getItemString("default/server", "127.0.0.1");
		String _username = c.getItemString("default/username", "root");
		String _password = c.getItemString("default/password", "");
		
		this.server.setText(_server);
		this.username.setText(_username);
		this.password.setText(_password);			
	}
	
	public void saveConfig()
	{
		File f = new File("config.xml");
		AfConfig c = new AfConfig(f);

		// 加载xml
		try
		{
			c.load();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		String _server =  server.getText().trim();
		String _username = username.getText().trim();
		String _password = password.getText().trim();
		
		c.setItemString("default/server", _server);	
		c.setItemString("default/username", _username);	
		c.setItemString("default/password", _password);	
		
		try
		{
			c.save();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	//
	private void doConnect()
	{
		new AfAsyncTask() {

			AfSqlConnection conn;
			
			@Override
			protected void doInBackground() throws Exception
			{
				String _server = server.getText().trim();
				String _username = username.getText().trim();
				String _password = password.getText().trim();
				
				conn = new AfSqlConnection();
				String jdbcUrl = AfMySQL.jdbcUrl(_server, 3306, "information_schema");
				conn.connect(jdbcUrl, _username, _password);
			}

			@Override
			protected void onPostExecute()
			{
				// 出错提示
				if(status < 0)
				{
					MyToastr.i.show(AfToastr.Level.ERROR, reason);
					return;
				}
				
				DBInfo info = (DBInfo)intent;
				info.conn = conn;
				startActivity(DatabaseActivity.class, info);
			}
			
		}.execute();;
	}
	

}
