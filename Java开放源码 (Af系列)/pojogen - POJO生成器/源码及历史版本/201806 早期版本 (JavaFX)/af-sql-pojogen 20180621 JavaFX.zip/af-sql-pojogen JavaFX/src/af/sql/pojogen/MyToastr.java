package af.sql.pojogen;

import af.javafx.toastr.AfToastr;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.stage.Window;

public class MyToastr extends AfToastr
{
	public static MyToastr i;
	
	public static void install(Window owner)
	{
		if(i== null) i= new MyToastr(owner);
	}
	
	public MyToastr(Window owner)
	{
		super(owner);
		
		this.pos = Pos.TOP_CENTER;
	}
}
