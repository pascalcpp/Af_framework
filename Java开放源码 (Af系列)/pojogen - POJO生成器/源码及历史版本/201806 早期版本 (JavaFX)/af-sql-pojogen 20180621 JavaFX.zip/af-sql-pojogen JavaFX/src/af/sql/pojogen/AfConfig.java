package af.sql.pojogen;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class AfConfig
{
	File file; // xml文件
	Document doc; // 解析后的dom

	//
	// path <-> item
	private Map<String, Item> items = new HashMap<String, Item>();
	// [group]
	private List<Group> groups = new ArrayList<Group>();

	public AfConfig(File file)
	{
		this.file = file;
	}

	// 加载
	public void load() throws Exception
	{
		InputStream stream = new FileInputStream(file);
		SAXReader reader = new SAXReader();

		/* 此reader需传入一个InputStream */
		doc = reader.read(stream);

		stream.close();
		build();
	}

	public void build() throws Exception
	{
		Element root = doc.getRootElement();
		List<Element> groups_ele = root.elements("group");
		for (Element group : groups_ele)
		{
			Group g = new Group();
			g.name = group.attributeValue("name").trim();
			g.descr = group.attributeValue("descr");

			List<Element> items_ele = group.elements("item");
			for (Element item : items_ele)
			{
				Item it = new Item();
				it.name = item.attributeValue("name").trim();
				it.descr = item.attributeValue("descr");
				it.type = item.attributeValue("type");
				if (it.type == null)
					it.type = "string";

				it.text = item.getText().trim();
				it.value = it.text.trim();
				if (it.type.equals("int"))
				{
					it.value = Integer.valueOf(it.text);
				}

				it.group = g.name;
				it.path = g.name + "/" + it.name;
				it.element = item;

				items.put(it.path, it);
				g.items.add(it);
			}
			groups.add(g);
		}
	}

	// 保存
	public void save() throws Exception
	{
		OutputFormat format = OutputFormat.createPrettyPrint();
		format.setEncoding(doc.getXMLEncoding());

		XMLWriter writer = new XMLWriter(new FileOutputStream(file), format);
		writer.write(doc);
		writer.close();
	}

	//////////// ITEM的获取 ///////////
	public Object getItem(String path)
	{
		return items.get(path);
	}

	public String getItemString(String path, String defValue)
	{
		Item it = items.get(path);
		if (it == null)
			return defValue;
		return (String) it.value;
	}

	public Integer getItemInt(String path, Integer defValue)
	{
		Item it = items.get(path);
		if (it == null)
			return defValue;
		return (Integer) it.value;
	}

	public void setItemString(String path, String value)
	{
		Item item = items.get(path);
		item.value = value;
		item.element.setText(value);
	}

	public void setItemInt(String path, Integer value)
	{
		Item item = items.get(path);
		item.value = value;
		item.element.setText(value.toString());
	}

	////////// 遍历接口 //////////////
	// 获取所有group
	public List<Group> getGroups()
	{

		return groups;
	}

	// 只获取一个group
	public Group getGroup(String path)
	{
		for (Group g : groups)
		{
			if (g.name.equals(path))
			{
				return g;
			}
		}
		return null;
	}

	///////////////////////////////////
	///////////////////////////
	public static class Group
	{
		public String name;
		public String descr;

		public List<Item> items = new ArrayList<Item>();
	}

	public static class Item
	{
		public String name;
		public String descr;
		public String type;
		public Object value;
		public String text;

		public String group;
		public String path;

		public Element element;
	}

}
