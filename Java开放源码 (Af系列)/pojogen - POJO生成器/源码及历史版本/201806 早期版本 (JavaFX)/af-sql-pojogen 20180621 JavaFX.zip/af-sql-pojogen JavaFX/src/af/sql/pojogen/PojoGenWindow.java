package af.sql.pojogen;


import af.javafx.activity.AfActivity;
import af.javafx.activity.AfActivityContext;
import af.javafx.activity.AfActivityObserver;
import af.javafx.layout.AfLayoutPane;
import af.sql.pojogen.activity.ConnectActivity;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class PojoGenWindow extends BorderPane implements AfActivityObserver
{ 
	
	AfActivityContext activityContext = new AfActivityContext();
	
	
	public PojoGenWindow()
	{
		initLayout();
		
		activityContext.setObserver(this);
		
		DBInfo info = new DBInfo();
		activityContext.startActivity(null, ConnectActivity.class, info);
	}

	private void initLayout()
	{
		this.getStyleClass().add("main");
		
		HeadBar head = new HeadBar();
		this.setTop(head);
		
		
		head.close.setOnAction((e)->{
			Platform.exit();
		});
	}
	
	@Override
	public void onActivityDismiss(AfActivity a)
	{
		
	}

	@Override
	public void onActivityShow(AfActivity a)
	{
		this.setCenter(a.getContentView());
		
	}
	
	//
	private class HeadBar extends AfLayoutPane
	{
		Image icon = new Image(getClass().getResource("ic_close.png").toExternalForm());
		Button close = new Button("", new ImageView(icon));
		Label title = new Label("POJO生成器 (afsql配套工具) Build 20180621");
		
		public HeadBar()
		{
			close.getStyleClass().add("window-close-button");
			this.getChildren().addAll(title, close);
			this.setPrefHeight(50);
			this.getStyleClass().add("headbar");
			title.getStyleClass().add("title");
			
		}
		
		@Override
		protected void layoutChilderen(double w, double h)
		{
			title.resizeRelocate(0, 0, w,h);
			close.resizeRelocate(w-24, 4, 20,20);
		}
		
	}
}
