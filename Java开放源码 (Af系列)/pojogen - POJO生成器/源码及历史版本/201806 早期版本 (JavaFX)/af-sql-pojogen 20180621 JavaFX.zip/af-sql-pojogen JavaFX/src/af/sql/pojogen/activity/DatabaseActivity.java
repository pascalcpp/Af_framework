package af.sql.pojogen.activity;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import af.javafx.activity.AfActivity;
import af.javafx.image.AfImageView;
import af.javafx.image.AfImageView.ScaleType;
import af.javafx.layout.AfHBox;
import af.javafx.layout.AfLayoutPane;
import af.javafx.scrollpane.AfListPane;
import af.javafx.task.AfAsyncTask;
import af.javafx.toastr.AfToastr;
import af.sql.AfSqlConnection;
import af.sql.pojogen.DBInfo;
import af.sql.pojogen.MyToastr;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

/* 
 * 选择数据库
 */

public class DatabaseActivity extends AfActivity
{
	static Image icCheck = new Image(DatabaseActivity.class.getResource("ic_check.png").toExternalForm());
	static Image icUncheck = new Image(DatabaseActivity.class.getResource("ic_uncheck.png").toExternalForm());
	
	//
	BorderPane ui = new BorderPane();
	AfListPane listPane = new AfListPane();
	Button button = new Button("下一步");
	
	//
	DBInfo info ;
	
	public DatabaseActivity()
	{
		
	}
	
	@Override
	public void onCreate(Object intent)
	{
		// 获取参数
		info = (DBInfo) intent;		
		
		// 布局		
		this.setContentView(ui);
		
		//
		Label title = new Label("请选择数据库");
		title.getStyleClass().add("title");
		ui.setTop(title);
		
		//
		ui.setCenter(listPane);
		ui.getStyleClass().add("activity");
		//
		AfHBox hbox = new AfHBox();
		hbox.getChildren().addAll(new Label(), button);
		hbox.setLayout("1 80px");
		hbox.getStyleClass().add("hbox");
		
		ui.setBottom( hbox);
		
		// 
		button.setOnAction( (e)->{
			goNext();
		});
	}
	
	public void add(String name)
	{
		ItemView itemView = new ItemView(name);
		itemView.setUserData(name);
		itemView.addEventFilter(MouseEvent.MOUSE_CLICKED, itemClickHandler);
		listPane.add(itemView);
	}
	
	public void selectAll(boolean selected)
	{
		ObservableList<Node> nodes = listPane.getItems();
		for(Node node : nodes)
		{
			ItemView view = (ItemView) node;
			view.setSelected(selected);
		}		
	}
	
	public List<String> getSelected()
	{
		List<String> result = new ArrayList<>();
		
		ObservableList<Node> nodes = listPane.getItems();
		for(Node node : nodes)
		{
			ItemView view = (ItemView) node;
			if(view.isSelected())
			{
				String data = (String) view.getUserData();
				result.add(data);
			}
		}	
		return result;
	}
	
	EventHandler<MouseEvent> itemClickHandler = (e)->{
		
		ItemView view = (ItemView)e.getSource();
		if( ! view .isSelected())
		{
			selectAll(false);
			view.setSelected(true);
		}
	};

	@Override
	public void onStart()
	{
		new AfAsyncTask() {
			
			List<String> names = new ArrayList<>();

			@Override
			protected void doInBackground() throws Exception
			{				
				String sql = "select schema_name from schemata";
				ResultSet rs = info.conn.executeQuery(sql);
				while(rs.next())
				{
					String name = rs.getString(1);
					
					// 不显示系统数据库
					if(true)
					{
						if(name.compareToIgnoreCase("mysql")==0
								|| name.compareToIgnoreCase("information_schema")==0
								|| name.compareToIgnoreCase("performance_schema")==0)
						{
							continue;
						}
					}
					
					names.add(name);
				}				
			}

			@Override
			protected void onPostExecute()
			{
//				for(String name: names)
//				{
//					System.out.println("数据库名: " + name);					
//				}
				for(String s: names) add(s);
			}			
		}.execute();
	}

	@Override
	public void onStop()
	{
		
	}
	
	private void goNext()
	{
		List<String> catalog = getSelected();
		if(catalog.size() == 0)
		{
			MyToastr.i.show(AfToastr.Level.WARN, "请选择数据库!");
			return;
		}
		
		// 下一个界面
		info.catalog = catalog.get(0);
		startActivity( TableActivity.class, info);
	}
	
	///////////////////////////////
	private class ItemView extends AfHBox
	{
		AfImageView icon = new AfImageView(); // 添加一行图标显示
		Label label = new Label();
		
		// 选中状态
		boolean selected = false;
		
		public ItemView(String name)
		{		
			this.getChildren().addAll(icon, label);
			this.setLayout("24px 1");
			this.setPrefWidth(9999);
			this.getStyleClass().add("item");
			this.setSpacing(10);
			this.setPadding(new Insets(4));
			
			//this.setStyle("-fx-background-color:#f00");
			label.setText(name);
			
			icon.setScaleType(ScaleType.CENTER_INSIDE);
			icon.setImage(icUncheck);
//			icon.setOnMouseClicked((e)->{
//				setSelected( ! selected ); // 切换选中状态
//				e.consume(); // 消费这个事件，避免被二次处理
//			});			
		}	
		
		// 检查当前是否被选中
		public boolean isSelected()
		{
			return selected;
		}
		// 设置选中状态
		public void setSelected(boolean selected)
		{
			this.selected = selected;
			if(selected)
				icon.setImage(icCheck);
			else
				icon.setImage(icUncheck);
		}
	}
}
