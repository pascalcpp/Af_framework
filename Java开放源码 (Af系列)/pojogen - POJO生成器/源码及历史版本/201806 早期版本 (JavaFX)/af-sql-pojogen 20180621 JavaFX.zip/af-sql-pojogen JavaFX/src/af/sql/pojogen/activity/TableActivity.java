package af.sql.pojogen.activity;

import java.io.File;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import af.javafx.activity.AfActivity;
import af.javafx.image.AfImageView;
import af.javafx.image.AfImageView.ScaleType;
import af.javafx.layout.AfHBox;
import af.javafx.scrollpane.AfListPane;
import af.javafx.task.AfAsyncTask;
import af.sql.AfSqlConnection;
import af.sql.AfSqlWhere;
import af.sql.pojogen.AfConfig;
import af.sql.pojogen.DBInfo;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

public class TableActivity extends AfActivity
{
	static Image icCheck = new Image(TableActivity.class.getResource("ic_check.png").toExternalForm());
	static Image icUncheck = new Image(TableActivity.class.getResource("ic_uncheck.png").toExternalForm());
	
	// 输入参数
	DBInfo info;

	// ui
	TextField m_pkg = new TextField();
	AfListPane listPane = new AfListPane();
	
	CheckBox check = new CheckBox("全选/取消 (可以只选择部分表生成POJO)");
	Button button = new Button("下一步");
	
	public TableActivity()
	{
		
	}
	
	@Override
	public void onCreate(Object intent)
	{
		// 取得参数
		info = (DBInfo) intent;	
		
		// 布局
		BorderPane root = new BorderPane();
		this.setContentView(root);
		root.getStyleClass().add("activity");
		
		// 
		AfHBox top = new AfHBox();
		top.getChildren().addAll(new Label("package:"), m_pkg);
		top.setLayout("60px 1");		
		root.setTop(top);		
		top.setPrefHeight(40);
		top.setPadding(new Insets(2));
		root.setCenter(listPane);
		//BorderPane.setMargin(m_pkg, new Insets(10,0,10,0));
		
		//
		AfHBox bottom = new AfHBox();
		bottom.getChildren().addAll(check, new Label(), button);
		bottom.setLayout("300px 1 80px");
		bottom.getStyleClass().add("hbox");		
		bottom.setPrefHeight(40);
		top.setPadding(new Insets(4));
		
		root.setBottom( bottom);
		
		m_pkg.setPromptText("请指定package路径");
		
		check.setSelected(true);
		check.setOnAction((e)->{
			selectAll( check.isSelected());
		});
		
		// 
		button.setOnAction( (e)->{
			goNext();
		});
	}

	@Override
	public void onStart()
	{
		loadConfig();
		listPane.requestFocus();
		
		new AfAsyncTask() {
			
			List<String> names = new ArrayList<>();

			@Override
			protected void doInBackground() throws Exception
			{				
				AfSqlWhere where = new AfSqlWhere();
				where.add2("table_schema", info.catalog);
				
				String sql = "select table_name from tables" + where;
				ResultSet rs = info.conn.executeQuery(sql);
				while(rs.next())
				{
					String name = rs.getString(1);
					names.add(name);
				}				
			}

			@Override
			protected void onPostExecute()
			{
//				for(String name: names)
//				{
//					System.out.println("数据库名: " + name);					
//				}
				for(String s: names) add(s);
				selectAll(true);
			}			
		}.execute();
	}

	@Override
	public void onStop()
	{
		
	}
	
	private void goNext()
	{
		
		String packageName = m_pkg.getText().trim();
		info.tables = getSelected();
		info.packageName = packageName;		
		startActivity( GenerateActivity.class, info);		
		
		saveConfig();
	}
	
	public void loadConfig()
	{
		File f = new File("config.xml");
		AfConfig c = new AfConfig(f);

		// 加载xml
		try
		{
			c.load();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		String packageName = c.getItemString("default/packageName", "my");
		this.m_pkg.setText(packageName);

	}
	
	public void saveConfig()
	{
		File f = new File("config.xml");
		AfConfig c = new AfConfig(f);

		// 加载xml
		try
		{
			c.load();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		String packageName =  m_pkg.getText().trim();
		c.setItemString("default/packageName", packageName);	

		
		try
		{
			c.save();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void add(String name)
	{
		ItemView itemView = new ItemView(name);
		itemView.setUserData(name);
		itemView.addEventHandler(MouseEvent.MOUSE_CLICKED, itemClickHandler);
		listPane.add(itemView);
	}
	
	public void selectAll(boolean selected)
	{
		ObservableList<Node> nodes = listPane.getItems();
		for(Node node : nodes)
		{
			ItemView view = (ItemView) node;
			view.setSelected(selected);
		}		
	}
	
	public List<String> getSelected()
	{
		List<String> result = new ArrayList<>();
		
		ObservableList<Node> nodes = listPane.getItems();
		for(Node node : nodes)
		{
			ItemView view = (ItemView) node;
			if(view.isSelected())
			{
				String data = (String) view.getUserData();
				result.add(data);
			}
		}	
		return result;
	}
	
	EventHandler<MouseEvent> itemClickHandler = (e)->{
		
		ItemView view = (ItemView)e.getSource();
		if( ! view .isSelected())
		{
			view.setSelected(true);
		}
	};

	
	///////////////////////////////
	private class ItemView extends AfHBox
	{
		AfImageView icon = new AfImageView(); // 添加一行图标显示
		Label label = new Label();
		
		// 选中状态
		boolean selected = false;
		
		public ItemView(String name)
		{		
			this.getChildren().addAll(icon, label);
			this.setLayout("24px 1");
			this.setPrefWidth(9999);
			this.getStyleClass().add("item");
			this.setSpacing(10);
			this.setPadding(new Insets(4));
			
			//this.setStyle("-fx-background-color:#f00");
			label.setText(name);
			
			icon.setScaleType(ScaleType.CENTER_INSIDE);
			icon.setImage(icUncheck);
			icon.setOnMouseClicked((e)->{
				setSelected( ! selected ); // 切换选中状态
				e.consume(); // 消费这个事件，避免被二次处理
			});			
		}	
		
		// 检查当前是否被选中
		public boolean isSelected()
		{
			return selected;
		}
		// 设置选中状态
		public void setSelected(boolean selected)
		{
			this.selected = selected;
			if(selected)
				icon.setImage(icCheck);
			else
				icon.setImage(icUncheck);
		}
	}

}
