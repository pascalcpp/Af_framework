package af.sql.pojogen;

import java.util.List;

import af.sql.AfSqlConnection;

public class DBInfo
{
	public AfSqlConnection conn;
	public String catalog;
	public String packageName;
	public List<String> tables;
}
