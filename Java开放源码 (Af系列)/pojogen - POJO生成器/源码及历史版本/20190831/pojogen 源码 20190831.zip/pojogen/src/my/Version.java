package my;

public class Version
{
	public static String build = "Build 20190831";
}
