package af.common.html;

import java.io.File;

public interface AfHtmlImageConverter
{
	// true: 不处理此url; false, 处理此url
	public boolean filter(String oritinalUrl) ;
	public String file2Url (String originalUrl, File localFile, Object context) throws Exception;
	
}
