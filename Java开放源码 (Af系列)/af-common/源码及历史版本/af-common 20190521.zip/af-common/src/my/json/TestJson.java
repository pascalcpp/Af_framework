package my.json;

import af.common.json.AfJSON;

public class TestJson
{

	public static void main(String[] args)
	{
		String s = " a [ abc }";
		
		int type = AfJSON.guessType(s);
		
		System.out.println("type:" + type);;

	}

}
