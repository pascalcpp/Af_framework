package af.sql;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import af.sql.mapping.AfSqlPojo;
import af.sql.mapping.AfSqlMapping;

public class AfSqlConnection
{
	
	//
	public Connection conn;	
	
	//
	String lastSQL = ""; // 最后一次sql
	
	public AfSqlConnection()
	{		
	}
	
	// 外部创建好jdbc connection然后传进来
	public AfSqlConnection(Connection conn)
	{		
		this.conn = conn;
	}
	
	// 连接数据库
	public void connect (String ip, int port, 
			String catalog,
			String username,
			String password) throws Exception
	{
		// 示例 jdbc:mysql://127.0.0.1:3306/af_school?useUnicode=true&characterEncoding=UTF-8
		String urlfmt = "jdbc:mysql://%s:%d/%s?useUnicode=true&characterEncoding=UTF-8";
		String connectionUrl = String.format(urlfmt, ip, port, catalog);
		
		conn = DriverManager.getConnection(connectionUrl, username, password);		
	}
	
	public void connect (String connectionUrl,
			String username,
			String password) throws Exception
	{
		conn = DriverManager.getConnection(connectionUrl, username, password);		
	}
	
	/////////// C3P0连接池支持 /////////////////
	/* 使用C3P0Pool 类 */
	////////////////////////////////////////////
	
	// 关闭连接
	public void close()
	{
		try {
			conn.close();
		}catch(Exception e) {}
	}
	
	// 最近一次query的sql
	public String getLastSQL ()
	{
		return lastSQL;
	}
	
	// 事务
	public void beginTransaction() throws SQLException
	{
		conn.setAutoCommit(false);
	}
	public void commit() throws SQLException
	{
		conn.commit();
	}
	public void rollback() throws SQLException
	{
		conn.rollback();
	}
	
	public void execute(String sql) throws Exception
	{
		this.lastSQL = sql;
		Statement stmt = conn.createStatement(); 
		stmt.execute(sql);		
	}
	
	// 执行查询
	public ResultSet executeQuery(String sql) throws Exception
	{
		this.lastSQL = sql;
		Statement stmt = conn.createStatement(); 
		ResultSet rs = stmt.executeQuery(sql);
		return rs;
	}
		
	// 执行查询, 并自动映射 (不要求POJO中有注解)
	public List executeQuery(String sql, Class clazz) throws Exception
	{
		this.lastSQL = sql;
		Statement stmt = conn.createStatement(); 
		ResultSet rs = stmt.executeQuery(sql);
		
		// 取得每一列的名称和类型
		ResultSetMetaData rsmd = rs.getMetaData();
		int numColumns = rsmd.getColumnCount(); // 一共几列
		String[] labels = new String[numColumns]; // 每列的标题
		int[] types = new int[numColumns];  // 每列的类型
		for(int i=0; i<numColumns; i++) 
		{			
			int columnIndex = i + 1; // 列序号
			labels[i] = rsmd.getColumnLabel(columnIndex); // 列标题
			types[i] = rsmd.getColumnType(columnIndex); // 类型, 参考 java.sql.Types定义	
			//System.out.println("type: " + types[i] + ",name: " + rsmd.getColumnTypeName(columnIndex));
		}
				
		// 反射: 找出每列对应的setter, 例如, 列名为name，则找到setName()
		// Method[] setters = AfSqlReflect.findSetter(clazz, labels);
		AfSqlPojo asc = AfSqlMapping.i.findClass(clazz.getName(), null);
		if(asc == null)
			asc = AfSqlMapping.i.findClass(clazz); // 从注解来提取			
		
		Method[] setters = asc.findSetters(labels);
		
		// 要返回的POJO list
		List rows = new ArrayList(); 
		
		AfSqlReflect reflect = new AfSqlReflect();
		
		// 映射为POJO
		while(rs.next())
	    {			
			// POJO对象
			Object pojo = clazz.newInstance();		
			rows.add(pojo);
			
	    	// 取出每一列的值，通过setter设给POJO对象
	    	for(int i=0; i<numColumns; i++)
	    	{
	    		int columnIndex = i+1;
	    		String columnValue = rs.getString(columnIndex); // 每列的值
	    		
	    		try {
	    			reflect.map(pojo, setters[i], types[i], columnValue);
	    		}catch(Exception e)
	    		{
	    			e.printStackTrace();
	    		}	    		
	    	}	    	
	    }
		
		return rows;
	}
	
	// 支持 Byte, Short, Int, Long, String, Date, Boolean, Double, Float
	// 如果不想使用自增，就指定autoIncrementColumnName=null
	public void insert(Object pojo) throws Exception 
	{
		Class clazz = pojo.getClass();
		
		// 从afsql-mapping.xml里查找相关描述, 或者自动从类信息中获取描述
		AfSqlPojo asc = AfSqlMapping.i.findClass(clazz.getName(), null);
		if(asc == null)
			asc = AfSqlMapping.i.findClass(pojo.getClass()); // 从注解来提取			
		
		if(asc.table == null)
			throw new Exception("类 " + clazz.getName() + "中无AFTABLE注解! 无法自动插入!");
		
		
		// sc.table就是表名
		AfSqlInsert asi = new AfSqlInsert(asc.table);
			
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		// 类的属性名 <-> 列名
		for(AfSqlPojo.Property p : asc.properties) // sc.properties
		{
			String fieldName = p.name; // 列名
			
			Method getter = AfSqlReflect.findGetter(clazz, fieldName);
			try {
				Object value = getter.invoke(pojo); // 每一列的值
				if(value != null)
				{
					if(value instanceof Boolean) 
					{
						Boolean v = (Boolean)value;
						value = v ? "1" : "0";
					}
					else if(value instanceof Date)
					{
						Date v =  (Date) value;						
						value = sdf.format(v);
					}
						
					asi.add(fieldName, value.toString());
				}
			}catch(Exception e)
			{				
			}
		}
		
		// 执行INSERT语句
		String sql = asi.toString();
		this.lastSQL = sql;
		
		AfSql.log("INSERT SQL:" + sql);
		Statement stmt = conn.createStatement(); 
		if(asc.generatedKey == null)
		{
			// 无自增ID
			stmt.execute(sql);
		}
		else
		{
			// 自增ID处理
			// 1 如果用户在插入时已经自己指定了一个值，则MySQL会使用这个值，并返回这个值
			// 2 如果用户在插入时未定自增主键的值，则MySQL会生成一个自增的值，并返回
			stmt.execute(sql,Statement.RETURN_GENERATED_KEYS);
			ResultSet keys = stmt.getGeneratedKeys(); 		
			if(keys.next())
			{
				// 取回自增的ID
				String id = keys.getString(1);
				Object arg0=null;
				try {
					Method setter = AfSqlReflect.findSetter(clazz, asc.generatedKey);
					AfSqlReflect.setIntValue(pojo, setter, id);
				}catch(Exception e)
				{					
				}
	        }
		}
		
	}
}
