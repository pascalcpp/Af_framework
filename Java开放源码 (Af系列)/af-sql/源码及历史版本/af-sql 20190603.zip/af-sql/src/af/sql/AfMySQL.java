package af.sql;

/* MySQL工具类
 * 
 */

public class AfMySQL
{
	// 转义 替换 \ 和 '
	public static String escape(String sql)
	{
		StringBuffer sb = new StringBuffer(sql.length() * 2);
		for(int i=0; i<sql.length(); i++)
		{
			char ch = sql.charAt(i);
			if(ch=='\'' || ch == '\\')
			{
				sb.append('\\')	;		
			}

			sb.append(ch);			
		}
		return sb.toString();
	}
	
	public static String jdbcUrl(String ip, int port, String catalog)
	{
		if(catalog == null)
		{
			String urlfmt = "jdbc:mysql://%s:%d";
			return String.format(urlfmt, ip, port);				
		}
		else
		{
			String urlfmt = "jdbc:mysql://%s:%d/%s?useUnicode=true&characterEncoding=UTF-8";
			return String.format(urlfmt, ip, port, catalog);
		}
	}
		
}
