package af.sql.mapping;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import af.sql.AfSqlReflect;
import af.sql.annotation.AFCOLUMN;
import af.sql.annotation.AFCOLUMNS;
import af.sql.annotation.AFTABLE;

public class AfSqlPojo
{
	public String name;  // 类名
	public String table; // 表名
	public Class clazz;
	
	public List<Property> properties = new ArrayList<>();
	public String generatedKey; // 自增主键的列名
	
	public Map<String,Method> getters = new HashMap<>();
	public Map<String,Method> setters = new HashMap<>();
	
	public static class Property
	{
		public String name;// 属性名, 须与列名相同
		public String type; // 映射成的Java类, 未使用
		public boolean primaryKey = false;// 未使用
		public int displaySize = 0; // 未使用
		public boolean isNotNull = false; // 未使用
		public String arg1; // 未使用
		public String arg2; // 未使用
		public String arg3;
		public String arg4;
	}
	
	
	// 通过字段名，找到对应的getter, 例如列名为birthday，则找到名为getBirthday()的方法
	public Method findGetter(String columnName)
	{
		return getters.get(columnName);
	}
	
	public Method[] findGetters(String[] columns)
	{
		Method[] mm = new Method[columns.length];
		for(int i=0; i<columns.length; i++)
		{
			mm[i] = getters.get( columns[i]);
		}
		return mm;
	}
	
	// 通过字段名，找到对应的setter, 例如列名为birthday，则找到名为setBirthday()的方法
	public Method findSetter(String columnName)
	{
		return setters.get(columnName);
	}
		
	public Method[] findSetters(String[] columns)
	{
		Method[] mm = new Method[columns.length];
		for(int i=0; i<columns.length; i++)
		{
			mm[i] = setters.get( columns[i]);
		}
		return mm;
	}
	
	////////////////////////////////////////////////////
	
	// 从类信息中，解析出映射关系
	public void parse(Class clazz) throws Exception
	{
		this.name = clazz.getName(); // name	
		this.clazz = clazz;
		
		if( clazz.isAnnotationPresent(AFTABLE.class))
		{
			// 如果类中有AFTABLE, AFCOLUMNS, AFCOLUMN注解，则根据注解来解析
			parseWithAnnotation( clazz );
		}
		else
		{
			// 该类没有AFTABLE注解，当只当作普通类操作，只得到getter和setter
			//throw new Exception("类" + clazz.getName() + "里没有AFTABLE注解!");
			parseWithoutAnnotation(clazz);
		}		
	}
	
	private void parseWithAnnotation(Class clazz)
	{
		// 提取 AFTABLE 注解，得到表名
		AFTABLE aftable = (AFTABLE)clazz.getAnnotation(AFTABLE.class);
		this.table = aftable.name(); 
		
		// 提取 AFCOLUMNS 注解，得到所有列名
		if(clazz.isAnnotationPresent(AFCOLUMNS.class))
		{
			AFCOLUMNS a = (AFCOLUMNS)clazz.getAnnotation(AFCOLUMNS.class);
			boolean auto = a.auto();
			String names = a.names();
			String generated = a.generated();
			if(auto)
			{
				// 列名 <-> 字段名 自动匹配
				Field[] fields = clazz.getDeclaredFields();
				for(Field field :fields)
				{
					AfSqlPojo.Property p = new AfSqlPojo.Property();
					this.properties.add( p );
					
					// 提取出每一列
					p.name = field.getName();
					p.type = "varchar";
					if(p.name.equals(generated))
					{
						this.generatedKey = generated;
					}
					
					this.getters.put( p.name,  AfSqlReflect.findGetter(this.clazz, p.name));
					this.setters.put( p.name,  AfSqlReflect.findSetter(this.clazz, p.name));
				}
			}
		}
		else
		{
			// 分别提取列名
			Field[] fields = clazz.getDeclaredFields();
			for(Field field :fields)
			{
				if(field.isAnnotationPresent(AFCOLUMN.class))
				{
					AFCOLUMN a = (AFCOLUMN) field.getAnnotation(AFCOLUMN.class);
					
					AfSqlPojo.Property p = new AfSqlPojo.Property();
					this.properties.add( p );
					
					// 提取出每一列
					p.name = a.name();
					p.type = a.type();
					if( a.generated() )
					{
						this.generatedKey = a.name();
					}
					
					this.getters.put( p.name,  AfSqlReflect.findGetter(this.clazz, p.name));
					this.setters.put( p.name,  AfSqlReflect.findSetter(this.clazz, p.name));
				}
			}
		}		
	}
	
	// 即使类里没有注解，也可以解析, 但无法得到表名
	private void parseWithoutAnnotation(Class clazz)
	{
		// 列名 <-> 字段名 自动匹配
		Field[] fields = clazz.getDeclaredFields();
		for(Field field :fields)
		{
			AfSqlPojo.Property p = new AfSqlPojo.Property();
			this.properties.add( p );
			
			// 提取出每一列
			p.name = field.getName();
			p.type = "varchar";
			
			this.getters.put( p.name,  AfSqlReflect.findGetter(this.clazz, p.name));
			this.setters.put( p.name,  AfSqlReflect.findSetter(this.clazz, p.name));
		}
	}

}
