package af.sql.c3p0;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import af.sql.AfSqlConnection;

/* 如果应用程序里要连接多个数据源，那么应该建立多个 AfC3p0Pool
 * 
 * 如果用用程序里只有一个数据源(单数据源），则可以使用 AfC3p0Factory ，或者自己建一个C3p0Factory
 * 
 */
public class AfC3P0Pool
{
	public ComboPooledDataSource c3p0 = new ComboPooledDataSource();
	
	public AfC3P0Pool()
	{
	}
	
	public void config(String username, String password)
	{
		c3p0.setUser(username);
		c3p0.setPassword(password);
	}
	
	public void config(String jdbcUrl, String username, String password)
	{
		c3p0.setJdbcUrl(jdbcUrl);
		config(username, password);
	}	
	
	// 从c3p0获取连接
	public AfSqlConnection getConnection() throws Exception
	{
		AfSqlConnection afconn = new AfSqlConnection(c3p0.getConnection());
		return afconn;
	}
	
}
