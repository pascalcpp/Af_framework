package af.sql.mapping;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import af.sql.AfSql;
import af.sql.AfSqlReflect;
import af.sql.annotation.AFCOLUMN;
import af.sql.annotation.AFCOLUMNS;
import af.sql.annotation.AFTABLE;

public class AfSqlMapping
{
	List<AfSqlPojo> classes = new ArrayList<>(); // class list
	Map<String, AfSqlPojo> classes_map1 = new HashMap<>(); // className -> class
	Map<String, AfSqlPojo> classes_map2 = new HashMap<>(); // tableName -> class
	
	// 单例
	private AfSqlMapping()
	{		
	}
	
	public static AfSqlMapping i;
	
	// static加载
	static {
		i = new AfSqlMapping();
		try
		{
			i.load();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	// 加载 afsql-mapping.xml
	public void load() throws Exception
	{
		InputStream inputStream = getClass().getResourceAsStream("/afsql-mapping.xml");
		if(inputStream==null) return; // 找不到 afsql-mapping.xml
		
		SAXReader xmlReader = new SAXReader(); 
		
		Document x_doc = xmlReader.read(inputStream);
		Element x_root = x_doc.getRootElement();
		inputStream.close();
		
		List<Element> x_classes = x_root.elements("class");
		for(Element x_class : x_classes)
		{
			AfSqlPojo asc = new AfSqlPojo();			
			asc.name = x_class.attributeValue("name");
			asc.table = x_class.attributeValue("table");
			asc.clazz = Class.forName(asc.name);
			
			List<Element> x_props = x_class.elements("property");
			for(Element x_prop : x_props)
			{
				AfSqlPojo.Property prop = new AfSqlPojo.Property();
				asc.properties.add(prop);
				
				prop.name = x_prop.attributeValue("name");
				prop.type = x_prop.attributeValue("type");	
				
				// 把getter和setter都准备好
				asc.getters.put( prop.name,  AfSqlReflect.findGetter(asc.clazz, prop.name));
				asc.setters.put( prop.name,  AfSqlReflect.findSetter(asc.clazz, prop.name));
			}
			
			addClass(asc);
		}
	}
	
	public void addClass(AfSqlPojo asc)
	{
		classes.add(asc);
		classes_map1.put(asc.name, asc);
		classes_map1.put(asc.table, asc);
	}
	
	// 查找类描述
	public AfSqlPojo findClass(String className, String tableName)
	{
		if(className != null)
		{
			AfSqlPojo r = classes_map1.get(className);
			if(r!= null) return r;
		}
		if(tableName != null)
		{
			AfSqlPojo r = classes_map2.get(tableName);
			if(r!= null) return r;
		}
		return null;
	}
	
	// 从类的注解里获取
	public AfSqlPojo findClass(Class pojoClazz) throws Exception
	{
		// 描述信息
		AfSqlPojo asc = new AfSqlPojo();
		asc.parse(pojoClazz);
		
		// 保存这个类的信息
		AfSql.log("成功从类" + pojoClazz.getName() +"中提取Mapping!");
		addClass(asc);
		
		return asc;
	}
}
