package af.sql;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import af.sql.mapping.AfSqlPojo;

/*
 * 支持 byte, short, int ,long, float, double, boolean
 *     Byte, Short, Integer, Long, Float, Double, Boolean
 *     String的自动映射
 * 除此之外的类型，请手动调用 setter, 例如Date类型，应在map之后再自己另外处理
 */
public class AfSqlReflect
{
	
	SimpleDateFormat sdf_d = new SimpleDateFormat("yyyy-MM-dd");
	SimpleDateFormat sdf_t = new SimpleDateFormat("HH:mm:ss");
	SimpleDateFormat sdf_dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	/*
	 * 支持 TINYINT,SMALLINT, INT, BIGINT, DOUBLE,FLOAT
	 *     CHAR, VCHAR
	 *     DATE, TIME, DATETIME
	 */
	// AfSqlReflect.map() 里面有sdf格式化, 不支持线程重入
	public void map(Object pojo, Method method, 
			int columnType,
			String columnValue) throws Exception
	{
		//System.out.println("列类型: " + columnType + ", 值: " + columnValue);
		if(method == null) return;
		if(columnValue == null) return;
		
		
		// 根据类型，传递合适的参数给setter
		Object arg0 = null;
		if(columnType == Types.CHAR || columnType == Types.VARCHAR )
		{
			arg0 = columnValue; // 给方法传一个String参数
		}
		else if( columnType == Types.LONGVARCHAR)  //text
		{
			arg0 = columnValue;
		}
		else if(columnType == Types.BIT) // tinyint(1)
		{
			arg0 = (columnValue.equals("1"));
		}
		else if(columnType == Types.DATE) // date
		{			
			arg0 = sdf_d.parse(columnValue);
		}
		else if(columnType == Types.TIME) // time
		{
			arg0 = sdf_t.parse(columnValue);
		}
		else if(columnType == Types.TIMESTAMP) // datetime timestamp
		{			
			arg0 = sdf_dt.parse(columnValue);
		}
		else if (columnType == Types.REAL) // SQLite里的REAL类型,对应double或float
		{
			Class[] parameterTypes = method.getParameterTypes();
			Class c = parameterTypes[0];
			if(c.equals( double.class) || c.equals(Double.class))
			{
				arg0 =  Double.valueOf(columnValue);
			}
			else if(c.equals( float.class) || c.equals(Float.class))
			{
				arg0 =  Float.valueOf(columnValue);
			}			
		}
		else if(columnType == Types.TINYINT || columnType == Types.SMALLINT
				|| columnType == Types.INTEGER || columnType == Types.BIGINT
				|| columnType == Types.DOUBLE || columnType == Types.FLOAT)
		{
			// 整数类型的处理
			Class[] parameterTypes = method.getParameterTypes();
			Class c = parameterTypes[0];
			if(c.equals( int.class) || c.equals(Integer.class))
			{
				arg0 = Integer.valueOf(columnValue);
			}
			else if(c.equals( long.class) || c.equals(Long.class))
			{
				arg0 =  Long.valueOf(columnValue);
			}	
			else if(c.equals( short.class) || c.equals(Short.class))
			{
				arg0 =  Short.valueOf(columnValue);
			}
			else if(c.equals( byte.class) || c.equals(Byte.class))
			{
				arg0 =  Byte.valueOf(columnValue);
			}
			else if(c.equals( float.class) || c.equals(Float.class))
			{
				arg0 =  Float.valueOf(columnValue);
			}
			else if(c.equals( double.class) || c.equals(Double.class))
			{
				arg0 =  Double.valueOf(columnValue);
			}			
		}

		// 调用setter方法
		Object args[] = { arg0 };
		try {
			method.invoke(pojo, args);
		}catch(IllegalArgumentException e)
		{
			Class[] parameterTypes = method.getParameterTypes();
			Class c = parameterTypes[0];
			//System.out.println("期望类型:" + c.getCanonicalName() + "，实际类型:" + arg0.getClass().getCanonicalName() );
		}
		
	}
	
	public static void setIntValue(Object pojo, Method setter, String value) throws Exception
	{
		Object arg0 = null;
		
		// 整数类型的处理
		Class[] parameterTypes = setter.getParameterTypes();
		Class c = parameterTypes[0];
		if(c.equals( int.class) || c.equals(Integer.class))
		{
			arg0 = Integer.valueOf(value);
		}
		else if(c.equals( long.class) || c.equals(Long.class))
		{
			arg0 =  Long.valueOf(value);
		}	
		else if(c.equals( short.class) || c.equals(Short.class))
		{
			arg0 =  Short.valueOf(value);
		}
		else if(c.equals( byte.class) || c.equals(Byte.class))
		{
			arg0 =  Byte.valueOf(value);
		}
		
		Object args[] = { arg0 };
		try {
			if(arg0 != null) setter.invoke(pojo, args);
		}catch(IllegalArgumentException e)
		{
			//System.out.println("期望类型:" + c.getCanonicalName() + "，实际类型:" + arg0.getClass().getCanonicalName() );
		}		
	}

	
	/////////////////////////////////////////////////////
	
	/////////////////////////////////////////////////////
	// 属性名 -> 方法名
	public static String getter(String fieldName)
	{
		// "name" -> "getName()"
		char firstChar = Character.toUpperCase(fieldName.charAt(0));
		StringBuffer strbuf = new StringBuffer("get" + fieldName);
		strbuf.setCharAt(3, firstChar);
		return strbuf.toString();
	}
	
	public static String setter(String fieldName)
	{
		// "name" -> "getName()"
		char firstChar = Character.toUpperCase(fieldName.charAt(0));
		StringBuffer strbuf = new StringBuffer("set" + fieldName);
		strbuf.setCharAt(3, firstChar);
		return strbuf.toString();
	}
	
	////////////////////////////////////////////////////
	// 根据列标题，找到对应的方法
	public static Method findSetter(Class cls, String fieldName)
	{
		// "name" -> "setName()"
		String methodName = setter(fieldName);
		Method[] methods = cls.getMethods();
		for (Method m : methods)
		{
			if (m.getName().equals(methodName))
			{
				return m;
			}
		}
		return null;
	}
	
	// 根据列标题，找到对应的方法
	public static Method[] findSetter(Class cls, String[] labels)
	{
		Method[] methods = new Method[ labels.length ];
		
		for(int i=0; i<labels.length; i++)
		{
			methods[i] = findSetter(cls, labels[i]);
		}
		
		return methods;
	}
	
	
	/////////////////////////////////////////////////////////////	
	// 查找getter
	public static Method findGetter(Class cls, String fieldName)
	{
		// "name" -> "getName()"
		String methodName = getter(fieldName);
		Method[] methods = cls.getMethods();
		for (Method m : methods)
		{
			if (m.getName().equals(methodName))
			{
				return m;
			}
		}
		return null;
	}
		
	public static Method[] findGetter(Class cls, String[] labels)
	{
		Method[] methods = new Method[ labels.length ];
		
		for(int i=0; i<labels.length; i++)
		{
			methods[i] = findGetter(cls, labels[i]);
		}
		
		return methods;
	}
	
	

	

	
}
