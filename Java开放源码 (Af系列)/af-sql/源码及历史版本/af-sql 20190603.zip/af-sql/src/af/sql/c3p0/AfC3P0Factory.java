package af.sql.c3p0;

import java.sql.ResultSet;
import java.util.List;

import af.sql.AfSqlConnection;

/* 如果应用程序里只有一个数据源，可以仿照这个类，自己建一个C3P0Factory
 * 
 */

public class AfC3P0Factory
{
	private static AfC3P0Pool pool = null;
	
	/* 全局对象初始化 */
	static {
		pool = new AfC3P0Pool();
	}
	
	/* 获取连接 */
	public static AfSqlConnection getConnection() throws Exception
	{
		return pool.getConnection();
	}
	
	
	// 查询 在conn.close()之后,resultset不可以访问
//	public static ResultSet executeQuery(String sql) throws Exception
//	{
//		AfSqlConnection connection = getConnection();
//		try{
//			return connection.executeQuery(sql);
//		}finally{
//			connection.close();
//		}
//	}
	
	// 查询，并自动映射到pojo，返回pojo列表
	public static List executeQuery(String sql, Class clazz) throws Exception
	{
		AfSqlConnection connection = getConnection();
		try{
			return connection.executeQuery(sql, clazz);
		}finally{
			connection.close();
		}	
	}
	
	// 获取唯一一行记录
	public static Object get(String sql, Class clazz)throws Exception
	{
		AfSqlConnection connection = getConnection();
		try{
			List rows = executeQuery(sql, clazz);
			if(rows == null || rows.size()== 0)
			{
				return null;
			}
			else 
			{
				return rows.get(0);
			}
		}finally{
			connection.close();
		}	
	}
	
	// 插入 insert
	public static void insert(Object pojo)throws Exception
	{
		AfSqlConnection connection = getConnection();
		try{
			connection.insert(pojo);
		}finally{
			connection.close();
		}	
	}
	
	// 执行 insert update delete 等SQL
	public static void execute(String sql) throws Exception
	{
		AfSqlConnection connection = getConnection();
		try{
			connection.execute(sql);
		}finally{
			connection.close();
		}	
	}
	

	
}
