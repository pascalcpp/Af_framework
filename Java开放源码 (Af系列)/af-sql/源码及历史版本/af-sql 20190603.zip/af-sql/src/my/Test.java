package my;

import java.util.List;

import af.sql.AfSqlConnection;

public class Test
{

	// 
	public static void main(String[] args) throws Exception
	{
		AfSqlConnection conn = new AfSqlConnection();
		conn.connect("127.0.0.1", 3306, "example", "root", "a1b2c3");
		
		Student s = new Student();
		//s.id = 20;
		s.name = "haha";
		
		conn.insert(s);
		
		System.out.println("新增主键为: " + s.id);
		
//		String sql = "select * from student";
//		List<Student> rows = conn.executeQuery(sql, Student.class);
		
		conn.close();
	}

}
