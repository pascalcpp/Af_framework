package my;

import java.util.List;

import af.sql.AfSqlConnection;

public class TestRowLock
{

	// 
	public static void main(String[] args) throws Exception
	{
		AfSqlConnection conn = new AfSqlConnection();
		
		System.out.println("连接数据库...");
		conn.connect("127.0.0.1", 3306, "af_school", "root", "shineon@1234");
		
		conn.conn.setAutoCommit(false);
		
		System.out.println("锁定 id=20180001的这行 ...");
		
		// 数据库使用InnoDB
		// WHERE使用索引限定，才是行锁；如果该列不是索引，则升级为表锁
		String sql1 = "select * from student where id='20180001' FOR UPDATE";
		conn.execute(sql1);
		
		Thread.sleep(30 * 1000); // 锁定30秒
		
//		String sql = "select * from student";
//		List<Student> rows = conn.executeQuery(sql, Student.class);
		conn.conn.commit();
		conn.close();
		System.out.println("退出");
	}

}
