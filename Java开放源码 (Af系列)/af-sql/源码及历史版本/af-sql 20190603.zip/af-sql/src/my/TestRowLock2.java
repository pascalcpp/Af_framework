package my;

import java.util.List;

import af.sql.AfSqlConnection;

public class TestRowLock2
{

	// 1 如果要使用行锁，则在数据库应该使用 InnoDB 引擎 (默认就是这个）
	// 2 启用事务，在事务里加行锁
	// 3 WHERE子句来限定一行或多行，该列必须已经建立索引或主键（普通索引即可，不要求是唯一索引）
	// 4 如果该列没有建立索引，则自动升级为表锁，即整张表都不可修改
	// 5 锁定期间，其他事务不可以修改表，但可以读取。其他请求如果要修改这个表、则Update语句会阻塞。
	public static void main(String[] args) throws Exception
	{
		AfSqlConnection conn = new AfSqlConnection();
		
		System.out.println("连接数据库...");
		conn.connect("127.0.0.1", 3306, "af_school", "root", "shineon@1234");
		
		conn.conn.setAutoCommit(false);
		
		System.out.println("试图锁定 phone=13810012345的这行 ...");
		System.out.println("由于phone不是索引，则所升级为表锁，整张表都无法修改  ...");
		// 数据库使用InnoDB
		// WHERE使用索引限定，才是行锁；如果该列不是索引，则升级为表锁
		String sql1 = "select * from student where phone='13810012345' FOR UPDATE";
		conn.execute(sql1);
		
		Thread.sleep(30 * 1000); // 锁定30秒
		
//		String sql = "select * from student";
//		List<Student> rows = conn.executeQuery(sql, Student.class);
		conn.conn.commit();
		conn.close();
		System.out.println("退出");
	}

}
