package af.swing.layout;

public class AfXLayout extends AfRowLayout
{
	public AfXLayout()
	{		
	}
	public AfXLayout(int gap)
	{		
		super(gap);
	}
	public AfXLayout(int gap, boolean usePerferredSize)
	{	
		super(gap, usePerferredSize);
	}
}
