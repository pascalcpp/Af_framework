package af.swing.style;

import java.awt.Color;

public class AfFontStyle
{
	public int size = 12;
	public String family = "微软雅黑 ";
	public Color color = Color.BLACK;
}
