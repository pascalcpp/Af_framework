package af.swing.style;

import java.awt.Color;

public class AfBorderStyle
{
	public int width = 1;
	public Color color = Color.GRAY;
	
	public AfBorderStyle()
	{		
	}
	public AfBorderStyle(Color color)
	{
		this.color = color;
	}
	public AfBorderStyle(Color color,int width)
	{
		this.color = color;
		this.width = width;
	}
}
