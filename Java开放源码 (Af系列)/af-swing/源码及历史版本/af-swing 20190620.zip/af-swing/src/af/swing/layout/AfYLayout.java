package af.swing.layout;

public class AfYLayout extends AfColumnLayout
{
	public AfYLayout()
	{		
	}
	public AfYLayout(int gap)
	{		
		super(gap);
	}
	public AfYLayout(int gap, boolean usePerferredSize)
	{	
		super(gap, usePerferredSize);
	}
}
